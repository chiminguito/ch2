using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.IO;


namespace Grafos
{
    public class Program
    {
        MyList lista = new MyList();

        //codify variables
        static byte vactual = 0;
        static Dictionary<char, byte> stcoding = new Dictionary<char, byte>();
        static Dictionary<byte, char> stdecoding = new Dictionary<byte, char>();
        //Fin codify variables

        public Program()
        {
            // leo y lleno la lista con los datos del archivo
            string path = "Assets/Resources/test.txt";
            string mensaje;
            //Read the text  directly from the test.txt file
            StreamReader reader = new StreamReader(path);
            while ((mensaje = reader.ReadLine()) != null)
            {
                if (mensaje.Contains(","))
                {

                    string coma = ",";
                    char comachar = coma[0];
                    mensaje.Split(comachar);
                    string[] neighbourtoadd = mensaje.Split(comachar);
                    lista.AddNeighbour(neighbourtoadd[0], int.Parse(neighbourtoadd[2]), neighbourtoadd[1]);

                }
                else
                {
                    lista.AddToEnd(mensaje);
                }

            }
            //FIN DE  leo y lleno la lista con los datos del archivo
            reader.Close();

            

            comprimiryescribir(lista.headNode,0);
            comprimiryescribir(lista.headNode, 1);

            /*
            foreach (KeyValuePair<string, int> item in lista.headNode.conexiones) //muestra conexiones dle primer pais
            {
                Debug.Log("Key: {0}, Value: {1}" + item.Key + item.Value);
            }
            */

            // CompressString("Its time to go to argentina, fly number 4568341", "Assets/Resources/coprimido.txt");
            CompressFile("Assets/Resources/sincoprimido.txt", "Assets/Resources/coprimido.txt");
            Debug.Log(DecompressFile("Assets/Resources/coprimido.txt"));



        }

        void comprimiryescribir(Nodo nodo,int estado) 
        {
            if (nodo.next != null && estado==1)
            {
                
                foreach (KeyValuePair<string, int> item in nodo.conexiones) //muestra conexiones dle primer pais
                {
                    
                    WriteString((nodo.name + "," + item.Key + ","+ item.Value), "Assets/Resources/sincoprimido.txt");
                    
                }
                comprimiryescribir(nodo.next,1);
            }

            if (nodo.next != null && estado == 0)
            {
                
                WriteString(nodo.name, "Assets/Resources/sincoprimido.txt");
                comprimiryescribir(nodo.next, 0);

            }
            
        }

        public void WriteString(string line_new , string path)
        {
            //Write some text to the test.txt file
            StreamWriter writer = new StreamWriter(path, true);
            writer.WriteLine(line_new);
            writer.Close();

        }

        //funciones codify
        static void WriteFile(String s, byte[] a)
        {
            File.WriteAllBytes(s, a);
        }

        static byte Ccodify(char l)
        {
            byte result;

            if (stcoding.TryGetValue(l, out result)) return result;
            else
            {
                stcoding.Add(l, vactual);
                stdecoding.Add(vactual, l);
                byte vanterior = vactual;
                vactual += 1;
                return vanterior;
            }

        }

        static char Cdecodify(byte n)
        {
            char result;
            if (stdecoding.TryGetValue(n, out result)) return result;
            else
            {
                return '?';
            }
        }


        static byte[] Scodify(String s)
        {
            byte[] cvalues = new byte[s.Length];
            for (int i = 0; i < s.Length; i++)
            {
                cvalues[i] = Ccodify(s[i]);
            }
            return cvalues;

        }


        static string Sdecodify(byte[] c)
        {
            char[] cvalues = new char[c.Length];

            for (int i = 0; i < c.Length; i++)
            {
                cvalues[i] = Cdecodify(c[i]);
            }
            string svalues = new string(cvalues);
            return svalues;

        }


        static byte[] Compress(byte[] data)
        {
            MemoryStream output = new MemoryStream();
            using (DeflateStream dstream = new DeflateStream(output, System.IO.Compression.CompressionLevel.Optimal))
            {
                dstream.Write(data, 0, data.Length);
            }
            return output.ToArray();
        }

        static byte[] Decompress(byte[] data)
        {
            MemoryStream input = new MemoryStream(data);
            MemoryStream output = new MemoryStream();
            using (DeflateStream dstream = new DeflateStream(input, CompressionMode.Decompress))
            {
                dstream.CopyTo(output);
            }
            return output.ToArray();
        }

        static void CompressFile(String origin, String destiny)
        {
            string message = ReadFile(origin);
            byte[] mcode = new byte[message.Length];
            mcode = Scodify(message);
            byte[] cmcode = Compress(mcode);

            WriteFile(destiny, cmcode);
        }

        static string DecompressFile(String origin)
        {
            byte[] lecture = File.ReadAllBytes(origin);
            byte[] dlecture = Decompress(lecture);
            string result = Sdecodify(dlecture);
            return result;

        }

        static void CompressString(String message, String destiny)
        {

            byte[] mcode = new byte[message.Length];
            mcode = Scodify(message);
            byte[] cmcode = Compress(mcode);

            WriteFile(destiny, cmcode);
        }


        static String ReadFile(String s) // funci�n para leer de texto
        {
            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(s))
                {
                    // Read the stream to a string, and write the string to the console.
                    String line = sr.ReadToEnd();
                    return line;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
                return null;

                //FIN funciones codify




            }
        }
    }
}
