﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafos
{
    public class readwrite : MonoBehaviour
    {
        public GameObject texto;


        public void ReadString()
        {
            Program program = new Program();

        }


        public void WriteString()
        {
            string path = "Assets/Resources/huff.txt";

            //Write some text to the test.txt file
            StreamWriter writer = new StreamWriter(path, true);
            writer.WriteLine(texto.GetComponent<UnityEngine.UI.Text>().text);
            writer.Close();

        }




    }
}