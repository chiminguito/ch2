﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Grafos
{
    class Program
    {
        /*
        public List<object> DijkstrasAlgorithm(MyList graf, Nodo start) {

            Dictionary<Nodo, int> totalCost = new Dictionary<Nodo, int>(); //Guarda el costo total del camino
            Dictionary<Nodo, Nodo> prevNodes = new Dictionary<Nodo, Nodo>(); //Guarda el camino mas corto
            PriorityQueue<Nodo> minPQ = new PriorityQueue<Nodo>();
            //Set

            totalCost.Add(start, 0); //El costo del primer nodo/raiz en 0
            minPQ.enqueue(start); //Agrega el nodo inicial a la lista de prioridad

            for (int i = 0; i <= graf.Lenght(); i++)
            {
                if(graf.headNode )
            }
        } 
        */

            private static int MinimumDistance(int[] distance, bool[] shortestPathTreeSet, int verticesCount)
            {
                int min = int.MaxValue;
                int minIndex = 0;

                for (int v = 0; v < verticesCount; ++v)
                {
                    if (shortestPathTreeSet[v] == false && distance[v] <= min)
                    {
                        min = distance[v];
                        minIndex = v;
                    }
                }

                return minIndex;
            }

            private static void Print(int[] distance, int verticesCount)
            {
                Console.WriteLine("Vertex    Distance from source");

                for (int i = 0; i < verticesCount; ++i)
                    Console.WriteLine("{0}\t  {1}", i, distance[i]);
            }

            public static void DijkstraAlgo(int[,] graph, int source, int verticesCount)
            {
                int[] distance = new int[verticesCount];
                bool[] shortestPathTreeSet = new bool[verticesCount];

                for (int i = 0; i < verticesCount; ++i)
                {
                    distance[i] = int.MaxValue;
                    shortestPathTreeSet[i] = false;
                }

                distance[source] = 0;

                for (int count = 0; count < verticesCount - 1; ++count)
                {
                    int u = MinimumDistance(distance, shortestPathTreeSet, verticesCount);
                    shortestPathTreeSet[u] = true;

                    for (int v = 0; v < verticesCount; ++v)
                        if (!shortestPathTreeSet[v] && Convert.ToBoolean(graph[u, v]) && distance[u] != int.MaxValue && distance[u] + graph[u, v] < distance[v])
                            distance[v] = distance[u] + graph[u, v];
                }

                Print(distance, verticesCount);
            }
        /*
            public static void ReadString()
            {
                string path = "E:/ENDAVA/Grafos/Grafos/test.txt";
                string mensaje;
                int count = 0;
                //Read the text from directly from the test.txt file
                StreamReader reader = new StreamReader(path);
                while ((mensaje = reader.ReadLine()) != null)
                {
                                      
                    //Detects conections
                    if (mensaje.Contains(",")){}
                    //Detects countries 
                    else
                    {
                        count++;                       
                    }                        
                    
                } 
                reader.Close();
            }
        */

             
            public static void CountryList()
            {
                int count = 0;
                int dim = 0;
                int count2 = 0;
                int dim2 = 0;
                string path = "E:/ENDAVA/Grafos/Grafos/test.txt";
                String line;
                List<string> countries = new List<string>(count);
                List<string> conections = new List<string>(count);
                using (StreamReader reader = File.OpenText(path))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(",")) 
                        {
                            conections.AddRange(line.Split(' '));
                            count2++; ;
                            dim2++;
                        }
                        else
                        {
                            if (line != String.Empty)
                            {
                                countries.AddRange(line.Split(' '));
                                count ++;;
                                dim++;
                            }
                        }
                    }
                }

                //Country list
                for (int i = 0; i < countries.Count; i++)
                {
                    Console.WriteLine(countries[i]);
                }
               
                //Conections index
                List<int> conections0 = new List<int>(count);
                List<int> conections1 = new List<int>(count);
                List<int> conections2 = new List<int>(count);
                int[,] matrix = new int[dim, dim];
                for (int i = 0; i < conections.Count; i++)
                {
                           Console.WriteLine(conections[i]);
                           string str = conections[i];
                           int comma = str.IndexOf(',');
                           string b = str;
                           if (comma != -1)
                           {
                               b = str.Substring(0, comma);
                           }
                           int a = countries.IndexOf(b);
                           conections0.Add(a);

                           string str1 = conections[i].Substring(conections[i].IndexOf(',') + 1);
                           int comma1 = str1.IndexOf(',');
                           string b1 = str1;
                           if (comma1 != -1)
                           {
                               b1 = str1.Substring(0, comma1);
                           }                         
                           int a1 = countries.IndexOf(b1);
                           conections1.Add(a1);

                           string str2 = conections[i].Split(',').Last();
                           int distance = Int32.Parse(str2);
                           conections2.Add(distance);

                           Console.WriteLine(conections0[i]);
                           Console.WriteLine(conections1[i]);
                           Console.WriteLine(conections2[i]);
                    
                }
                for (int i = 0; i < conections.Count; i++)
                {
                    matrix[(conections0[i]), (conections1[i])] = conections2[i];
                }
                DijkstraAlgo(matrix, 0, dim);
            }

            static void Main(string[] args)
        {
            /*
            MyList lista = new MyList();

           
            
            
            PriorityQueue<Nodo> miQueue = new PriorityQueue<Nodo>();

            


            //Console.WriteLine(miQueue.peek());

            lista.AddToEnd("china");
            lista.AddToEnd("venezuela");
            lista.AddToEnd("colombia");
            lista.AddToEnd("peru");
            lista.AddToEnd("Argentina");

            lista.AddToEnd("brazil");

            lista.AddNeighbour("colombia", 10, "venezuela");
            lista.AddNeighbour("colombia", 100, "peru");
            lista.AddNeighbour("colombia", 1070, "brazil");
            lista.AddNeighbour("china", 1070, "brazil");

            Console.Write(lista.Lenght());

            
            */
            CountryList();
            int[,] graph =  {
                         {0,0,4,10}, {0,0,5,0}, {6,0,0,0}, {0,0,0,0}
                        
                            };

                
            //DijkstraAlgo(graph, 0, 4);


            Console.ReadKey();

            
        }
    }
}
