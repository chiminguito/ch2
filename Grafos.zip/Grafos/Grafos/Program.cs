﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Grafos
{
    class Program
    {
        
        private static int MinimumDistance(int[] distance, bool[] shortestPathTreeSet, int verticesCount)
        {
            int min = int.MaxValue;
            int minIndex = 0;

            for (int v = 0; v < verticesCount; ++v)
            {
                if (shortestPathTreeSet[v] == false && distance[v] <= min)
                {
                    min = distance[v];
                    minIndex = v;
                }
            }

            return minIndex;
        }

        public static void PrintPath(int[] parent, int j,List<string> paises)
        {
            if (parent[j] == -1)
            {


                return;
            }


            PrintPath(parent, parent[j],paises);

            Console.Write("|" + paises[parent[j]] + "|-> ");

        }
        public static void Print(int[] distance, int verticesCount, int[] parents, List <string> paises,int source)
        {
            Console.WriteLine();
            Console.Write("Shortest path "+ paises[source]+ " ->all destination: ");
            Console.WriteLine();
            Console.WriteLine("Destination    Distance from " + paises[source]);

            for (int i = 0; i < verticesCount; ++i)
            {
                Console.Write("{0}\t  {1}\t ", paises[i], distance[i]);
                PrintPath(parents, i,paises);
                Console.Write(paises[i]);

              

                Console.WriteLine();
            }

            Console.WriteLine();
        }

        public static void Print_od(int[] distance, int verticesCount, int[] parents, int source, int destino, List<string> paises)
        {
            Console.Write("Shortest path " + paises[source] +" -> "+ paises[destino] + " :");
            Console.WriteLine();
            Console.WriteLine("Destination    Distance from "+paises[source]);

            for (int i = 0; i < verticesCount; ++i)
            {
                Console.Write("{0}\t  {1}\t ", paises[i], distance[i]);

                if(destino==i)
                {
                    
                    PrintPath(parents, i,paises);
                    Console.Write(paises[i]);
                    
                }

                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("If you want, choose a new destination:");

        }

        public static void DijkstraAlgo(int[,] graph, int source,int destiny, int verticesCount, List<string> paises)
        {
            Console.Clear();
            int[] distance = new int[verticesCount];
            bool[] shortestPathTreeSet = new bool[verticesCount];

            for (int i = 0; i < verticesCount; ++i)
            {
                distance[i] = int.MaxValue;
                shortestPathTreeSet[i] = false;
            }

            distance[source] = 0;
            int[] parents = new int[verticesCount];
            parents[source] = -1;

            for (int count = 0; count < verticesCount - 1; ++count)
            {
                int u = MinimumDistance(distance, shortestPathTreeSet, verticesCount);
                shortestPathTreeSet[u] = true;

                for (int v = 0; v < verticesCount; ++v)
                    if (!shortestPathTreeSet[v] && Convert.ToBoolean(graph[u, v]) && distance[u] != int.MaxValue && distance[u] + graph[u, v] < distance[v])
                    {
                        parents[v] = u;
                        distance[v] = distance[u] + graph[u, v];
                    }

            }
            Print(distance, verticesCount, parents, paises,source);
            Print_od(distance, verticesCount, parents,source, destiny,paises);


        }
        private static int index = 0;
        public static void menu(int[,] graph, int source, int destiny, int verticesCount, List<string> paises)
        {
           
            while (true)
            {
                string selected = draw(paises);

                for (int i = 0; i < paises.Count; i++)
                {
                    if (selected == paises[i])
                    {
                        Console.Clear();
                        Console.WriteLine("Please select your destination country:");
                        menu2(graph, i, 0, verticesCount,paises);
                    }
                }
                
            }
        }
        public static void menu2(int[,] matrix, int source, int destiny, int dim, List<string> countries)
        {

            while (true)
            {
                string selected = draw(countries);

                for (int i = 0; i < countries.Count; i++)
                {
                    if (selected == countries[i])
                    {
                        DijkstraAlgo(matrix, source, i, dim, countries);                       
                    }
                }
                
            }
        }
        private static string draw(List<string> pais)
            {
                for (int i = 0; i < pais.Count; i++)
                {
                    if (i == index)
                    {
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine(pais[i]);
                    }
                    else
                    {
                        Console.WriteLine(pais[i]);
                    }
                    Console.ResetColor();
                }
                ConsoleKeyInfo ckey = Console.ReadKey();

                if (ckey.Key == ConsoleKey.DownArrow)
                {
                    if (index == pais.Count - 1) { }
                    else
                    {
                        index++;
                    }
                }
                else if (ckey.Key == ConsoleKey.UpArrow)
                {
                    if (index <= 0) { }
                    else
                    {
                        index--;
                    }

                }
                else if (ckey.Key==ConsoleKey.Enter)
                {
                    return pais[index];
                }
                else
                {
                    return "";
                }
                
                
                Console.Clear();
                return "";
            }
        
        public static void CountryList()
            {
                int count = 0;
                int dim = 0;
                int count2 = 0;
                int dim2 = 0;
                string path = "C:/Users/dfigueredo/Desktop/Grafos/Grafos/test.txt";
                string compressedpath = "C:/Users/dfigueredo/Desktop/Grafos/Grafos/Stringcodified.txt";
                string description;
                if (File.Exists(compressedpath)) 
                {
                File.Delete(compressedpath);
                    compression.CompressFile(path, compressedpath);//comprimiendo
                    description =compression.DecompressFile(compressedpath);
                    //Console.WriteLine(description);
            }
                else
                {
                    compression.CompressFile(path, compressedpath);//comprimiendo
                    description = compression.DecompressFile(compressedpath);
                    //Console.WriteLine(description);
            }
                String line;
                List<string> countries = new List<string>(count);
                List<string> conections = new List<string>(count);
                using (StringReader reader = new StringReader(description))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(",")) 
                        {
                            conections.AddRange(line.Split(' '));
                            count2++; ;
                            dim2++;
                        }
                        else
                        {
                            if (line != String.Empty)
                            {
                                countries.AddRange(line.Split(' '));
                                count ++;;
                                dim++;
                            }
                        }
                    }
                }
            

            //Conections index
                List<int> conections0 = new List<int>(count);
                List<int> conections1 = new List<int>(count);
                List<int> conections2 = new List<int>(count);
                int[,] matrix = new int[dim, dim];
                for (int i = 0; i < conections.Count; i++)
                {
                           //Console.WriteLine(conections[i]);
                           string str = conections[i];
                           int comma = str.IndexOf(',');
                           string b = str;
                           if (comma != -1)
                           {
                               b = str.Substring(0, comma);
                           }
                           int a = countries.IndexOf(b);
                           conections0.Add(a);

                           string str1 = conections[i].Substring(conections[i].IndexOf(',') + 1);
                           int comma1 = str1.IndexOf(',');
                           string b1 = str1;
                           if (comma1 != -1)
                           {
                               b1 = str1.Substring(0, comma1);
                           }                         
                           int a1 = countries.IndexOf(b1);
                           conections1.Add(a1);

                           string str2 = conections[i].Split(',').Last();
                           int distance = Int32.Parse(str2);
                           conections2.Add(distance);

                           //Console.WriteLine(conections0[i]);
                           //Console.WriteLine(conections1[i]);
                           //Console.WriteLine(conections2[i]);
                    
                }
                for (int i = 0; i < conections.Count; i++)
                {
                    matrix[(conections0[i]), (conections1[i])] = conections2[i];
                }
            
            int band = 0;
            if (band == 0)
            {
                Console.WriteLine("Please select your origin country:");
                menu(matrix, 0, 0, dim, countries);
            }
            
            //DijkstraAlgo(matrix, 1, 3, dim, countries);
            // countries.IndexOf(o),
        }

        static void Main(string[] args)
        {
        Console.CursorVisible = false;
        CountryList();
        Console.ReadKey();

            
        }
    }
}

